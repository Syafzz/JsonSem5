


function output() {
var x = document.getElementById("list");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
let mainObj = {};
let miniObj = {};

fetch("student.json")

.then(function(response) {
	return response.json()
})

.then(function(data) {
	//JSON data
	//console.log(data);
	//console.log(data.class.length);
	//console.log(data.teacher);
	//console.log(data.students[2]);
	mainObj = data.class;
	miniObj = data.teacher;

	document.getElementById('papar').innerHTML = mainObj;
	document.getElementById('papar2').innerHTML = miniObj;

	let output='';
	for(var i = 0; i < data.students.length; i++) {
				output += '<li>'+data.students[i]+'</li>';
			}
			document.getElementById('papar3').innerHTML = output; 
})
